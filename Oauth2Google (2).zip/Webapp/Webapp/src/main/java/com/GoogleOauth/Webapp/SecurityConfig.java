package com.GoogleOauth.Webapp;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.oidc.IdTokenClaimNames;
import org.springframework.security.web.SecurityFilterChain;

@SuppressWarnings("deprecation")
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)
@EnableWebSecurity
public class SecurityConfig {
	@SuppressWarnings({ "deprecation", "removal" })
	@Bean
	protected SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.authorizeRequests(authorizeRequests -> authorizeRequests.requestMatchers("/", "/error", "/webjars/**")
				.permitAll()
				.anyRequest()
				.authenticated())
		.oauth2Login();
		return http.build();
	}

	@Bean
	public InMemoryClientRegistrationRepository clientRegistrationRepository() {
		ClientRegistration registration = ClientRegistration.withRegistrationId("google")
				.clientId("453023464235-kgrmgd9rb1casqpknkrmconrvkaicd80.apps.googleusercontent.com")
				.clientSecret("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")
				.authorizationUri("https://accounts.google.com/o/oauth2/auth")
				.redirectUri("http://localhost:8080/login/oauth2/code/google")
				.tokenUri("https://accounts.google.com/o/oauth2/token")
				.clientName("Google")
				.scope("openid","email","profile")
				.userInfoUri("https://www.googleapis.com/oauth2/v3/userinfo")
				.authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE)
				.userNameAttributeName(IdTokenClaimNames.SUB).build();
		return new InMemoryClientRegistrationRepository(registration);
	
	}

}
