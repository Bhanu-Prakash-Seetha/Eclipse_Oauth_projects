package com.Oauth2.springoauth2google;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringOauth2GoogleApplicationTests {

	//@Test
	void contextLoads() {
	}

}
