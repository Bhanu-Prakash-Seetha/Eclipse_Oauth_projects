package com.Oauth2.springoauth2google.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.Oauth2.springoauth2google.entities.MyUserDetails;
import com.Oauth2.springoauth2google.entity.Users;
import com.Oauth2.springoauth2google.repository.UserRepository;
@Service
public class UserDetailsServiceImpls implements UserDetailsService {
	
	@Autowired
	private UserRepository userRepo;
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		Users user = userRepo.getUserByUsername(username);
		if(user==null)
		{
			throw new UsernameNotFoundException(username+" not found!!");
		}
		return new MyUserDetails(user);
	}

}
