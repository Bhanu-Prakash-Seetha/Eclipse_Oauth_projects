package com.Oauth2.springoauth2google;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOauth2GoogleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringOauth2GoogleApplication.class, args);
	}

}
