package com.Oauth2.springoauth2google.entity;

public enum Provider {
	Google,Local,Facebook,Github
}
