package com.Oauth2.springoauth2google.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Oauth2.springoauth2google.entity.Provider;
import com.Oauth2.springoauth2google.entity.Users;
import com.Oauth2.springoauth2google.repository.UserRepository;
@Service
public class UserService {
	@Autowired
	public UserRepository userRepo;
	public void processOauthPostLogin(String username) {
		// TODO Auto-generated method stub
		Users existingUser = userRepo.getUserByUsername(username);
		if(existingUser==null) {
			existingUser.setUsername(username);
			existingUser.setProvider(Provider.Github);
			existingUser.setEnabled(true);
			userRepo.save(existingUser);
			System.out.println("Created new user: " + username);
		}
	}

}
