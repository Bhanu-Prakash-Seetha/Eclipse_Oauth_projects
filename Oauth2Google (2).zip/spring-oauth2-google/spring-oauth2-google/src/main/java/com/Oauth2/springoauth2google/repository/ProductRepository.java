package com.Oauth2.springoauth2google.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Oauth2.springoauth2google.entity.Products;
@Repository
public interface ProductRepository extends JpaRepository<Products, Integer>{

}
