package com.Oauth2.springoauth2google.service;

import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import com.Oauth2.springoauth2google.helper.CustomOauth2User;
@Service
public class CustomOauth2UserService extends DefaultOAuth2UserService {

	
	public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
		// TODO Auto-generated method stub
		OAuth2User oauth2user = super.loadUser(userRequest);
		System.out.println("CustomOAuth2UserService invoked");
		return new CustomOauth2User(oauth2user); 
	}

}
