package com.Oauth2.springoauth2google.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Oauth2.springoauth2google.entity.Products;
import com.Oauth2.springoauth2google.repository.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepo;
	
	public List<Products> listAll(){
		List<Products> list=productRepo.findAll();
		return list;
	}
	
	public void saveProduct(Products product) {
		productRepo.save(product);
	}
	
	public Products getProduct(int id) {
		return productRepo.findById(id).get();
	}
	
	public void deleteProduct(int id) {
		productRepo.deleteById(id);
	}
}
