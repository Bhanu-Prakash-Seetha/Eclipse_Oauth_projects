package com.Oauth2.springoauth2google.config;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.Oauth2.springoauth2google.helper.CustomOauth2User;
import com.Oauth2.springoauth2google.service.CustomOauth2UserService;
import com.Oauth2.springoauth2google.service.UserDetailsServiceImpls;
import com.Oauth2.springoauth2google.service.UserService;

@EnableWebSecurity
@Configuration
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	public UserService userService;

	@Autowired
	private CustomOauth2UserService oauthUserService;

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public UserDetailsService userDetailsService() {
		return new UserDetailsServiceImpls();
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// TODO Auto-generated method stub
		// super.configure(http);
		http.authorizeRequests().antMatchers("/", "/login", "/oauth/**").permitAll().anyRequest().authenticated().and()
				.formLogin().permitAll().loginPage("/login").usernameParameter("email").passwordParameter("pass")
				.defaultSuccessUrl("/list").and().oauth2Login().loginPage("/login").userInfoEndpoint()
				.userService(oauthUserService).and().successHandler(new AuthenticationSuccessHandler() {

					@Override
					public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
							Authentication authentication) throws IOException, ServletException {
						// TODO Auto-generated method stub
						System.out.println("Authentication success handler Invoked");
						System.out.println("Authentication name : " + authentication.getName());
						CustomOauth2User oauthuser = (CustomOauth2User) authentication.getPrincipal();
						userService.processOauthPostLogin(oauthuser.getEmail());
						response.sendRedirect("/list");
					}
				}).and().logout().logoutSuccessUrl("/").permitAll().and().exceptionHandling().accessDeniedPage("/403");

	}

	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
		provider.setPasswordEncoder(passwordEncoder());
		provider.setUserDetailsService(userDetailsService());
		return provider;
	}

	@Override protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// TODO Auto-generated method stub
		// super.configure(auth);
		auth.authenticationProvider(authenticationProvider());
	}

}
