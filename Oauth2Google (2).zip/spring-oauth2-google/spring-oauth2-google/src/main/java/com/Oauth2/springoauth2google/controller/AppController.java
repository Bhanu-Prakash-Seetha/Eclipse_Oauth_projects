package com.Oauth2.springoauth2google.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.Oauth2.springoauth2google.entity.Products;
import com.Oauth2.springoauth2google.service.ProductService;

@Controller
public class AppController {
	@Autowired
	private ProductService productservice;

	@RequestMapping("/list")
	public String viewHomepage(Model model) {
		List<Products> list = productservice.listAll();
		model.addAttribute("list", list);
		return "products";
	}

	@RequestMapping("/new")
	public String showNewProductForm(Model model) {
		Products product = new Products();
		model.addAttribute("product", product);
		return "new_product";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveProduct(Products product) {
		productservice.saveProduct(product);
		return "redirect:/list";
	}
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditProductForm(@PathVariable(name = "id") int id) {
		ModelAndView mav = new ModelAndView("edit_product");
		Products product = productservice.getProduct(id);
		mav.addObject("product", product);
		return mav;

	}
	@RequestMapping("/delete/{id}")
	public String deleteProduct(@PathVariable(name="id") int id) {
		productservice.deleteProduct(id);
		return "redirect:/list";
	}

}
