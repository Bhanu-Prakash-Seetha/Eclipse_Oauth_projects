package com.springsecurity.jwt.JwtApp.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springsecurity.jwt.JwtApp.modal.Employees;
import com.springsecurity.jwt.JwtApp.modal.JwtRequest;
import com.springsecurity.jwt.JwtApp.modal.JwtResponse;
import com.springsecurity.jwt.JwtApp.service.EmployeeService;
import com.springsecurity.jwt.JwtApp.utilities.JwtHelper;

@RestController
@RequestMapping("/api/emp")
public class CrudController {
	private Logger logger = LoggerFactory.getLogger(CrudController.class);
	
	@Autowired
	private EmployeeService empService;
	@Autowired
	private AuthenticationManager authManager;
	@Autowired
	private JwtHelper helper;

	@PostMapping("/save")
	public ResponseEntity<Employees> saveEmployees(@RequestBody Employees employee) {
		return new ResponseEntity(empService.createEmployee(employee), HttpStatus.CREATED);
	}

	@GetMapping("/get")
	public List<Employees> getAllEmployees() {
		return empService.getAllEmployees();
	}

	@PostMapping("/login")
	public ResponseEntity<JwtResponse> empLogin(@RequestBody JwtRequest request) {
		this.doAuthenticate(request.getUsername(), request.getPassword());
		UserDetails userDetails = empService.loadUserByUsername(request.getUsername());
		System.out.println("userdetails: "+userDetails.getUsername());
		String token = this.helper.generateToken(userDetails);
		logger.info("Generated token: "+token);
		JwtResponse response = new JwtResponse();
		response.setToken(token);
		response.setUsername(userDetails.getUsername());
		return new ResponseEntity(response,HttpStatus.OK);
		
		
	}

	private void doAuthenticate(String username, String password) {
		// TODO Auto-generated method stub
		UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(username, password);
		try {
			authManager.authenticate(authToken);
		} catch (Exception e) {
			throw new BadCredentialsException("invalid credentials!!");

		}
	}
}
