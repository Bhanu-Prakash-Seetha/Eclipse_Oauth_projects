package com.springsecurity.jwt.JwtApp.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springsecurity.jwt.JwtApp.modal.Employees;
@Repository
public interface EmployeeRepository extends JpaRepository<Employees,Integer>{
	public Employees findByUsername(String name);
}
