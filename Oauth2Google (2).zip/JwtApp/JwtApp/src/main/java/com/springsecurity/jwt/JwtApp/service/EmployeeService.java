package com.springsecurity.jwt.JwtApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.springsecurity.jwt.JwtApp.Repo.EmployeeRepository;
import com.springsecurity.jwt.JwtApp.modal.Employees;

@Service
public class EmployeeService implements UserDetailsService {
	@Autowired
	private EmployeeRepository empRepo;

	@Autowired
	private PasswordEncoder encoder;
	
	public ResponseEntity<Employees> createEmployee(Employees employee) {
		employee.setPassword(encoder.encode(employee.getPassword()));
		return new ResponseEntity<>(empRepo.save(employee), HttpStatus.CREATED);
	}

	public List<Employees> getAllEmployees() {
		List<Employees> list = empRepo.findAll();
		return list;
	}

	
	//finding username while logging in
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		Employees employee = empRepo.findByUsername(username);
		if(employee==null) {
			new UsernameNotFoundException("username not found!!");
		}
		return employee;
	}

}
