package com.springsecurity.jwt.JwtApp.controller;

public class AuthController {

}
