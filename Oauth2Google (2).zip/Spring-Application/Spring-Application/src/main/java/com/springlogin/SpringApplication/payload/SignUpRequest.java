package com.springlogin.SpringApplication.payload;

public class SignUpRequest {

}
