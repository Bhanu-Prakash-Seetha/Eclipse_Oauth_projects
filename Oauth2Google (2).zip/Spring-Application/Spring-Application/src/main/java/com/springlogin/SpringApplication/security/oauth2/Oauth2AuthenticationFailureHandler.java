package com.springlogin.SpringApplication.security.oauth2;

public class Oauth2AuthenticationFailureHandler {

}
