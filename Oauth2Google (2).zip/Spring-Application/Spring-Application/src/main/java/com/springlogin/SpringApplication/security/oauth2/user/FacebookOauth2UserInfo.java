package com.springlogin.SpringApplication.security.oauth2.user;

import java.util.Map;

public class FacebookOauth2UserInfo extends OAuth2UserInfo{

	public FacebookOauth2UserInfo(Map<String, Object> attributes) {
		super(attributes);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return (String) attributes.get("id");
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return (String) attributes.get("name");
	}

	@Override
	public String getEmail() {
		// TODO Auto-generated method stub
		return (String) attributes.get("email");
	}

	@Override
	public String getImageUrl() {
		// TODO Auto-generated method stub
		if(attributes.containsKey("picture")) {
			Map<String, Object> pictureObject = (Map<String, Object>) attributes.get("picture");
			if(pictureObject.containsKey("data")) {
				Map<String, Object> dataObject = (Map<String, Object>) attributes.get("data");
				if(dataObject.containsKey("url")) {
					return (String) attributes.get("url");
				}
			}
		}
		return null;
	}

}
