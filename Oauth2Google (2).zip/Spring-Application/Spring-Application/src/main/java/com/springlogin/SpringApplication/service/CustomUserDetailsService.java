package com.springlogin.SpringApplication.service;

public class CustomUserDetailsService {

}
