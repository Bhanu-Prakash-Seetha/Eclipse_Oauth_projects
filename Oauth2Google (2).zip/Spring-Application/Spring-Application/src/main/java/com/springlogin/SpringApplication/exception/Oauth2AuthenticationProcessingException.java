package com.springlogin.SpringApplication.exception;

public class Oauth2AuthenticationProcessingException {

}
