package com.springlogin.SpringApplication.security.oauth2;

public class CustomOauth2UserService {

}
