package com.springlogin.SpringApplication.security;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.springlogin.SpringApplication.entities.AuthProvider;
import com.springlogin.SpringApplication.entities.User;
import com.springlogin.SpringApplication.exception.Oauth2AuthenticationProcessingException;
import com.springlogin.SpringApplication.repository.UserRepository;
import com.springlogin.SpringApplication.security.oauth2.user.GoogleOauth2UserInfo;
import com.springlogin.SpringApplication.security.oauth2.user.OAuth2UserInfo;
import com.springlogin.SpringApplication.security.oauth2.user.Oauth2UserInfoFactory;

@Service
public class CustomUserDetailsService extends DefaultOAuth2UserService {
	@Autowired
	private UserRepository userRepo;

	@Override
	public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
		// TODO Auto-generated method stub
		OAuth2User oauth2User = super.loadUser(userRequest);
		try {
			return processOauth2User(userRequest, oauth2User);
		} catch (AuthenticationException ex) {
			throw ex;
		} catch (Exception e) {
			throw new InternalAuthenticationServiceException(e.getMessage(), e.getCause());
		}
		// return super.loadUser(userRequest);
	}

	@SuppressWarnings("deprecation")
	private OAuth2User processOauth2User(OAuth2UserRequest userRequest, OAuth2User oauth2User) {
		// TODO Auto-generated method stub
		OAuth2UserInfo oauth2UserInfo = Oauth2UserInfoFactory
				.getOAuth2UserInfo(userRequest.getClientRegistration().getRegistrationId(), oauth2User.getAttributes());
		if (StringUtils.isEmpty(oauth2UserInfo.getEmail())) {
			throw new Oauth2AuthenticationProcessingException("Email not found from Oauth2 Provider");
		}
		Optional<User> userOptional = userRepo.findByEmail(oauth2UserInfo.getEmail());
		User user;
		if (userOptional.isPresent()) {
			user = userOptional.get();
			if (!user.getAuthProvider()
					.equals(AuthProvider.valueOf(userRequest.getClientRegistration().getRegistrationId()))) {
				throw new OAuth2AuthenticationProcessingExcption(
						"Looks like you're signed up with " + user.getAuthProvider() + " account. Please use your "
								+ user.getAuthProvider() + " account to login.");
			}
			user=updateExistingUser(user, oauth2UserInfo);	
		}else {
			user=registerNewUser(userRequest,oauth2UserInfo);
		}
		return UserPrincipal.create(user,oauth2User.getAttributes());
	}
	
	private User registerNewUser(OAuth2UserRequest oAuth2UserRequest, OAuth2UserInfo oAuth2UserInfo) {
        User user = new User();

        user.setAuthProvider(AuthProvider.valueOf(oAuth2UserRequest.getClientRegistration().getRegistrationId()));
        user.setProviderId(oAuth2UserInfo.getId());
        user.setName(oAuth2UserInfo.getName());
        user.setEmail(oAuth2UserInfo.getEmail());
        user.setImageUrl(oAuth2UserInfo.getImageUrl());
        return userRepo.save(user);
    }

    private User updateExistingUser(User existingUser, OAuth2UserInfo oAuth2UserInfo) {
        existingUser.setName(oAuth2UserInfo.getName());
        existingUser.setImageUrl(oAuth2UserInfo.getImageUrl());
        return userRepo.save(existingUser);
    }

}
