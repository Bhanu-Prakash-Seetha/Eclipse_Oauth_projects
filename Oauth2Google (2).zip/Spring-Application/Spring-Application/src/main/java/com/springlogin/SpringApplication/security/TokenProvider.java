package com.springlogin.SpringApplication.security;

public class TokenProvider {

}
