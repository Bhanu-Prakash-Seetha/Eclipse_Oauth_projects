package com.springlogin.SpringApplication.entities;

public enum AuthProvider {
	local, google, facebook, github
}
