package com.springlogin.SpringApplication.security;

import java.util.Map;

import org.springframework.security.oauth2.core.user.OAuth2User;

import com.springlogin.SpringApplication.entities.User;

public class UserPrincipal {

	public static OAuth2User create(User user, Map<String, Object> attributes) {
		// TODO Auto-generated method stub
		return null;
	}

}
