package com.springlogin.SpringApplication.controller;

public class AuthController {

}
