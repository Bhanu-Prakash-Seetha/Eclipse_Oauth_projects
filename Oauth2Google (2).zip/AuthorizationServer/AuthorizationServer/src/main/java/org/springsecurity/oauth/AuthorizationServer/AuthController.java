package org.springsecurity.oauth.AuthorizationServer;

import java.security.Principal;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/rest/hello")
public class AuthController {
	@GetMapping("/principal")
	public Principal name(Principal principal) {
		return principal;
	}

	@GetMapping
	public String messsage() {
		return "Hello World";
	}
}
