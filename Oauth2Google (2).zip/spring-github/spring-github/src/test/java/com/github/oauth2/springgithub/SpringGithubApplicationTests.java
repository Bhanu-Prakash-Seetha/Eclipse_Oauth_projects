package com.github.oauth2.springgithub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringGithubApplicationTests {

	@Test
	void contextLoads() {
	}

}
