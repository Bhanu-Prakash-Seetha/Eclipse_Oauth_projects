package com.github.oauth2.springgithub.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.oauth2.springgithub.entity.Person;
import com.github.oauth2.springgithub.repo.PersonRepo;

@Service
public class PersonService {

	@Autowired
	private PersonRepo personRepo;

	public List<Person> getAllPersons() {
		return personRepo.findAll();
	}

	public Person createPerson(Person person) {
		return personRepo.save(person);
	}

	public List<Person> getPersonByUsername(String username) {
		return personRepo.findByUsername(username);
	}

	public Optional<Person> getPersonById(int id) {
		return personRepo.findById(id);
	}

	public void deleteById(int id) {
		personRepo.deleteById(id);
	}
	
	public Person updateById(int id,Person person) {
		Person existingPerson = personRepo.findById(id).orElse(null);
		if(existingPerson!=null) {
			existingPerson.setEmail(person.getEmail());
			existingPerson.setPassword(person.getPassword());
			return personRepo.save(existingPerson);
		}
		return null;
	}
}
