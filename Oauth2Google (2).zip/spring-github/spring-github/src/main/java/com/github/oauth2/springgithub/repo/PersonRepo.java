package com.github.oauth2.springgithub.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.github.oauth2.springgithub.entity.Person;
@Repository
public interface PersonRepo extends JpaRepository<Person,Integer>{

	public List<Person> findByUsername(String username);
}
