package com.github.oauth2.springgithub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringGithubApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringGithubApplication.class, args);
	}

}
