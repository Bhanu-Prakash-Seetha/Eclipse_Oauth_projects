package com.github.oauth2.springgithub.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.oauth2.springgithub.entity.Person;
import com.github.oauth2.springgithub.service.PersonService;

@RestController
@RequestMapping("/api")
public class MyController {

	@Autowired
	private PersonService pservice;

	@GetMapping("/get")
	public ResponseEntity<List<Person>> getAllPersons() {
		List<Person> persons = pservice.getAllPersons();
		return new ResponseEntity<>(persons, HttpStatus.OK);
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<Person> getById(@PathVariable int id) {
		Optional<Person> person_by_id = pservice.getPersonById(id);
		return person_by_id.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
				.orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
		// return new ResponseEntity(pservice.getPersonById(id),HttpStatus.OK);
	}

	@PostMapping("/create-person")
	public ResponseEntity<Person> createPerson(@RequestBody Person person) {
		return new ResponseEntity(pservice.createPerson(person), HttpStatus.CREATED);
	}

	@GetMapping("/get/{username}")
	public ResponseEntity<List<Person>> getByUsername(@RequestParam("username") String username) {
		List<Person> pusername = pservice.getPersonByUsername(username);
		return new ResponseEntity(pusername, HttpStatus.OK);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> deletebyid(@PathVariable int id) {
		pservice.deleteById(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
