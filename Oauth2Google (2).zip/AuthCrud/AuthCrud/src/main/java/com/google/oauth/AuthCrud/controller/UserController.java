package com.google.oauth.AuthCrud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.oauth.AuthCrud.entity.UsersEntity;
import com.google.oauth.AuthCrud.service.UserService;

@RestController
@RequestMapping("/api")
public class UserController {
	
	@Autowired 
	private UserService userService;
	
	@GetMapping("/data")
	public List<UsersEntity> getAllData(){
		return userService.getAlldata();
	}
}
