package com.google.oauth.AuthCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthCrudApplication.class, args);
	}

}
