package com.google.oauth.AuthCrud.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.JpaRepositoryConfigExtension;
import org.springframework.stereotype.Repository;

import com.google.oauth.AuthCrud.entity.UsersEntity;

@Repository
public interface UserDao extends JpaRepository<UsersEntity, Integer>{

}
