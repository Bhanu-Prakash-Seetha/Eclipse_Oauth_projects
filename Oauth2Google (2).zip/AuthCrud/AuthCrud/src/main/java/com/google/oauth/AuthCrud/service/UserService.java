package com.google.oauth.AuthCrud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.oauth.AuthCrud.dao.UserDao;
import com.google.oauth.AuthCrud.entity.UsersEntity;

@Service
public class UserService {
	@Autowired
	private UserDao userdao;
	
	public List<UsersEntity> getAlldata(){
		return userdao.findAll();
	}
}
